package com.jyotienterprises.store;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    // Replace both placeholders with your Supabase project URL and anon/public key.
    private static final String SUPABASE_URL = "https://YOUR_PROJECT.supabase.co";
    private static final String SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
    private static final String ADMIN_PHONE = "8890111327";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private LinearLayout root;
    private String phone = "", accessToken = "", role = "customer";
    private int navy = Color.rgb(15, 35, 65), blue = Color.rgb(37, 99, 235);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        showLogin();
    }

    private void shell(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 18, 20, 16); root.setBackgroundColor(Color.rgb(246,248,252));
        setContentView(root);
        TextView brand = new TextView(this); brand.setText("JYOTI ENTERPRISES");
        brand.setTextColor(navy); brand.setTextSize(23); brand.setTypeface(null, Typeface.BOLD);
        root.addView(brand);
        TextView heading = new TextView(this); heading.setText(title); heading.setTextColor(Color.DKGRAY);
        heading.setTextSize(16); heading.setPadding(0, 6, 0, 18); root.addView(heading);
    }
    private TextView text(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(Color.rgb(35,45,60)); t.setPadding(0,10,0,10); return t;
    }
    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setInputType(type);
        e.setTextSize(16); e.setPadding(14,10,14,10); e.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=12; root.addView(e,p); return e;
    }
    private void button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=9; root.addView(b,p);
        b.setOnClickListener(v -> action.run());
    }
    private void note(String msg) { new android.app.AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK",null).show(); }
    private boolean configured() { return !SUPABASE_URL.contains("YOUR_PROJECT") && !SUPABASE_ANON_KEY.contains("YOUR_SUPABASE"); }

    private void showLogin() {
        shell("Wholesale glove store");
        root.addView(text("Sign in with your mobile number. Supabase will send a one-time password (OTP).",16));
        EditText number = field("Mobile number with country code (91XXXXXXXXXX)", InputType.TYPE_CLASS_PHONE);
        button("Send OTP", () -> {
            String raw = number.getText().toString().replaceAll("[^0-9]","");
            if (raw.length()<10) { note("Enter a valid mobile number with country code, e.g. 91XXXXXXXXXX."); return; }
            if (!configured()) { note("Supabase is not connected yet. Follow README.md to add your project URL and anon/public key, then rebuild."); return; }
            phone = raw.startsWith("91") ? "+"+raw : "+91"+raw;
            io.execute(() -> {
                String result = request("/auth/v1/otp", "{\"phone\":\""+phone+"\",\"create_user\":true}", false);
                runOnUiThread(() -> { if (result.startsWith("ERROR:")) note("OTP could not be sent. Check Supabase Phone Auth and SMS provider settings.\n"+result); else showVerifyOtp(); });
            });
        });
        root.addView(text("Wholesale industrial cotton gloves • Order tracking • Business accounts",14));
    }
    private void showVerifyOtp() {
        shell("Verify mobile number"); root.addView(text("Enter the OTP sent to "+phone,16));
        EditText otp = field("OTP code",InputType.TYPE_CLASS_NUMBER);
        button("Verify and continue",() -> {
            String code=otp.getText().toString().trim();
            if(code.length()<4){note("Enter the OTP you received.");return;}
            io.execute(() -> {
                String result=request("/auth/v1/verify","{\"phone\":\""+phone+"\",\"token\":\""+code+"\",\"type\":\"sms\"}",true);
                runOnUiThread(() -> {
                    if(result.startsWith("ERROR:")){note("OTP verification failed. Check the code and try again.");return;}
                    try {
                        JSONObject obj=new JSONObject(result); accessToken=obj.optString("access_token","");
                        if(accessToken.isEmpty()){note("No login token received.");return;}
                        String normalized=phone.replaceAll("[^0-9]","");
                        role=(normalized.equals(ADMIN_PHONE)||normalized.equals("91"+ADMIN_PHONE))?"admin":"customer";
                        showHome();
                    } catch(Exception e){note("Could not read sign-in response.");}
                });
            });
        });
        button("Back",this::showLogin);
    }
    private String request(String path,String body,boolean verify) {
        HttpURLConnection c=null;
        try {
            c=(HttpURLConnection)new URL(SUPABASE_URL+path).openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(15000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("apikey",SUPABASE_ANON_KEY);
            c.setRequestProperty("Authorization","Bearer "+SUPABASE_ANON_KEY);
            try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}
            int status=c.getResponseCode(); java.io.InputStream stream=status>=200&&status<300?c.getInputStream():c.getErrorStream();
            Scanner scanner=new Scanner(stream,"UTF-8").useDelimiter("\\A"); String response=scanner.hasNext()?scanner.next():"";
            return status>=200&&status<300?response:"ERROR: "+response;
        } catch(Exception e){return "ERROR: "+e.getMessage();}
        finally{if(c!=null)c.disconnect();}
    }
    private void showHome() {
        shell("Welcome"); root.addView(text(role.equals("admin")?"Administrator access":"Welcome to our wholesale store",18));
        root.addView(text("Quality industrial cotton gloves for your business.",16));
        button("Browse products",this::showProducts); button("My cart",this::showCart);
        button("My orders",this::showOrders); button("My account",this::showProfile);
        if(role.equals("admin")) button("Admin dashboard",this::showAdmin);
        button("Sign out",()->{accessToken="";phone="";role="customer";showLogin();});
        root.addView(text("Signed in as "+phone,13));
    }
    private void simplePage(String title,String body) {
        shell(title); ScrollView sv=new ScrollView(this); LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL); content.addView(text(body,16)); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); button("Home",this::showHome);
    }
    private void showProducts() {
        shell("Products"); root.addView(text("40 gm Industrial Cotton Gloves",20));
        root.addView(text("Blue cotton knit • Sky-blue overlock • Wholesale packs",16));
        root.addView(text("Product pricing and stock need to be entered in Supabase.",14));
        button("Add 1 pack to cart",()->{getPreferences(0).edit().putInt("cart_count",getPreferences(0).getInt("cart_count",0)+1).apply();note("Added to cart.");});
        button("View cart",this::showCart); button("Home",this::showHome);
    }
    private void showCart() {
        int n=getPreferences(0).getInt("cart_count",0);
        shell("My cart"); root.addView(text("Industrial Cotton Gloves\nQuantity: "+n+"\n\nCheckout is a placeholder until database-backed order creation is configured.",16));
        button("Place order",()->note("Order creation is not connected yet. Configure Supabase and complete the order API before accepting real orders."));
        button("Home",this::showHome);
    }
    private void showOrders(){simplePage("My orders","Your order history will appear here after database-backed order retrieval is connected.");}
    private void showProfile(){simplePage("My account","Mobile: "+phone+"\nAccount type: "+role+"\nOTP login uses Supabase Auth when configured.");}
    private void showAdmin(){simplePage("Admin dashboard","JYOTI ENTERPRISES ADMIN\n\nProduct, inventory, wholesale pricing and order management screens need their database operations connected. Secure all privileged operations with Supabase Row Level Security.");}
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();}
}
