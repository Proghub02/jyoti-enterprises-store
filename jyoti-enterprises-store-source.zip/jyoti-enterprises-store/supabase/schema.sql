create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(), name text not null, description text not null default '',
  sku text unique, price numeric(12,2) not null default 0 check(price>=0),
  stock integer not null default 0 check(stock>=0), active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id),
  status text not null default 'pending' check(status in ('pending','confirmed','packed','shipped','delivered','cancelled')),
  total numeric(12,2) not null default 0 check(total>=0), notes text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id), quantity integer not null check(quantity>0),
  unit_price numeric(12,2) not null check(unit_price>=0)
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

create policy "profiles read own or admin" on public.profiles for select to authenticated
using (id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));
create policy "active products readable" on public.products for select to anon,authenticated
using (active or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));
create policy "admin manages products" on public.products for all to authenticated
using(exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'))
with check(exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));
create policy "customers read own orders" on public.orders for select to authenticated
using(user_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));
create policy "customers create own orders" on public.orders for insert to authenticated with check(user_id=auth.uid());
create policy "admin updates orders" on public.orders for update to authenticated
using(exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'))
with check(exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'));
create policy "order items read own or admin" on public.order_items for select to authenticated
using(exists(select 1 from public.orders o where o.id=order_id and (o.user_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin'))));
create policy "order items create own orders" on public.order_items for insert to authenticated
with check(exists(select 1 from public.orders o where o.id=order_id and o.user_id=auth.uid()));

-- Trigger assigns admin only after Supabase Auth creates/verifies the user.
create or replace function public.sync_profile_from_auth()
returns trigger language plpgsql security definer set search_path = '' as $$
declare n text;
begin
  n := regexp_replace(coalesce(new.phone,''),'[^0-9]','','g');
  insert into public.profiles(id,phone,role)
  values(new.id,new.phone,case when n in ('8890111327','918890111327') then 'admin' else 'customer' end)
  on conflict(id) do update set phone=excluded.phone,
    role=case when n in ('8890111327','918890111327') then 'admin' else public.profiles.role end;
  return new;
end;
$$;
create trigger on_auth_user_profile_sync after insert or update of phone on auth.users
for each row execute function public.sync_profile_from_auth();

insert into public.products(name,description,sku,price,stock,active)
values('40 gm Industrial Cotton Gloves','Blue cotton knit gloves with sky-blue overlock. Wholesale pack.','JE-CG-40',0,0,true)
on conflict(sku) do nothing;
