# JYOTI ENTERPRISES — Android store starter

Native Android app source with separate Home, Products, Cart, Orders, Account and Admin screens.

## Build an APK with GitHub Actions
1. Upload these files to `Proghub02/jyoti-enterprises-store` (the connected GitHub integration currently doesn't have permission to write to that repository).
2. Open **Actions → Build Android APK → Run workflow**.
3. Download the `jyoti-enterprises-debug-apk` artifact from the successful run and extract `app-debug.apk`.

## Connect Supabase
1. Create a Supabase project and enable Phone Auth and a configured SMS provider.
2. Run `supabase/schema.sql` in the Supabase SQL Editor.
3. Replace `SUPABASE_URL` and `SUPABASE_ANON_KEY` placeholders in `MainActivity.java` with your project URL and anon/public key.
4. Set actual prices, pack sizes, stock, shipping and payment process.

Never place the Supabase service-role key in an Android app. The anon key is public and all sensitive database operations must be enforced by Row Level Security.

## Important status
This is a starter build, not a complete production commerce application. OTP flow is wired for Supabase when configured. Products are currently a starter listing, cart is stored locally, and order submission, order history, admin editing, payment and live inventory still need database-backed implementation. The app's visible admin menu is a convenience only; authorization must be enforced server-side. The included database trigger provisions the admin role for the verified phone `8890111327` (including country-code form `+91 8890111327`).
